var classNodeEdge =
[
    [ "getPeso", "classNodeEdge.html#afca41a515e991fb76f90bcc3368497da", null ],
    [ "setPeso", "classNodeEdge.html#a4dc69269cfc61d71dbef0c0ce6bbb8fd", null ]
];