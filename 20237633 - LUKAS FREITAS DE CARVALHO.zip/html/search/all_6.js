var searchData=
[
  ['removearesta_0',['removeAresta',['../classGrafo__lista.html#a81196269ae03d761aa139eb38550ada6',1,'Grafo_lista::removeAresta()'],['../classGrafo__matriz.html#aea624fd4cf4f78b6d97b7c578b22cafd',1,'Grafo_matriz::removeAresta()']]]
];
