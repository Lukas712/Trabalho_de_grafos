var searchData=
[
  ['eh_5farvore_0',['eh_arvore',['../classGrafo__lista.html#a55f663b2ebddb096f2b6861e9e461257',1,'Grafo_lista::eh_arvore()'],['../classGrafo__matriz.html#aeb5c91e372b9282898254b309fe2421e',1,'Grafo_matriz::eh_arvore()']]],
  ['eh_5fbipartido_1',['eh_bipartido',['../classGrafo__lista.html#af08e48645dfb14e720836f6fe35d918e',1,'Grafo_lista::eh_bipartido()'],['../classGrafo__matriz.html#a88c1d7b608e2b25e8ef1ff579d6f0c77',1,'Grafo_matriz::eh_bipartido()']]],
  ['eh_5fcompleto_2',['eh_completo',['../classGrafo__lista.html#adb75edbf0baf2878ea2421407ed7fc14',1,'Grafo_lista::eh_completo()'],['../classGrafo__matriz.html#ab84f870e22960c0ffa6a88aef45d8b7e',1,'Grafo_matriz::eh_completo()']]]
];
