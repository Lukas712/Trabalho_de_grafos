var searchData=
[
  ['possuiarticulacao_0',['possuiArticulacao',['../classGrafo__lista.html#aadc2f2ab73280ab8f740fa3f3a58ee06',1,'Grafo_lista::possuiArticulacao()'],['../classGrafo__matriz.html#ac75bf3f8a69380ee4ddd1cf391c43c14',1,'Grafo_matriz::possuiArticulacao()']]],
  ['possuiponte_1',['possuiPonte',['../classGrafo__lista.html#a92829014e6be32034cbb1fc2c37745e4',1,'Grafo_lista::possuiPonte()'],['../classGrafo__matriz.html#a5f61a72b03ab63742e1f959ba9a951bd',1,'Grafo_matriz::possuiPonte()']]]
];
